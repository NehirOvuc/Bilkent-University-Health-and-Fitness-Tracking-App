import javax.swing.*;

public class Menu {
    private JComboBox comboBox1;
}
