import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Restaurants {
    private JPanel panel1;
    private JComboBox comboBox1;
    private JButton menuButtonBMC;
    private JPanel PanelMozart;
    private JPanel PanelKirac;
    private JPanel PanelBilkent;
    private JButton menuButtonMozart;
    private JButton menuButtonKirac;

    // Constructor
    public Restaurants() {

        // Create a JFrame for the Restaurants page
        JFrame restaurantsFrame = new JFrame("Restaurants");
        restaurantsFrame.setContentPane(panel1);  // Set the panel as the content pane of the frame
        restaurantsFrame.setSize(800, 800);
        restaurantsFrame.setLocationRelativeTo(null);  // Center the frame on the screen
        restaurantsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Show the Restaurants frame
        restaurantsFrame.setVisible(true);

        menuButtonBMC.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // BBMC
            }
        });
        menuButtonMozart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mozart
            }
        });
        menuButtonKirac.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Kirac
            }
        });
    }

}
